1. run 'npm i'
2. run 'mvn clean install'
3. test cases are in 'src/test/java/com/example/FuncTest.java'
4. POST service is in 'src/main/java/com/example/Func.java'

Please let me know if you have any questions.

Yanlong Wang
wangyanlong0107@gmail.com
+86 18640041127
