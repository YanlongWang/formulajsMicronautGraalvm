package com.example;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@MicronautTest
class FuncTest {

  private HttpClient client;

  private ObjectMapper objectMapper;

  @Inject
  public FuncTest(@Client("/") HttpClient client, ObjectMapper objectMapper) {
    this.client = client;
    this.objectMapper = objectMapper;
  }

  /**
   * Test case function: A1+A11
   * request json payload {"payload":{"A1":"5","A11":"6","func":"A1+A11"}}
   * response json        {"payload":{"A1":"5","A11":"6","func":"A1+A11","result":"11"}}
   * 结果在 "result" field which is 11
   */
  @Test
  public void testAdd() throws JsonProcessingException {
    String bodyStr = "{\"payload\":{\"A1\":\"5\",\"A11\":\"6\",\"func\":\"A1+A11\"}}";
    HttpRequest<String> request = HttpRequest.POST("/func", bodyStr);
    String body = client.toBlocking().retrieve(request);
    assertNotNull(body);
    assertEquals("11", ((Map) objectMapper.readValue(body, HashMap.class)
        .get("payload")).get(Func.RESULT));
  }

  /**
   * Test case function: IF(A1=0,A11,"==")
   * request payload json {"payload":{"A1":"0","A11":"'='","func":"IF(A1=0,A11,\"==\")"}}
   * response json        {"payload":{"A1":"0","A11":"'='","func":"IF(A1=0,A11,\"==\")","result":"="}}
   * 结果在 "result" field which is "="
   */
  @Test
  public void testIf() throws JsonProcessingException {
    Payload payload = new Payload();
    payload.put("A1", "0");
    payload.put("A11", "'='");
    payload.put("func", "IF(A1=0,A11,\"==\")");
    HttpRequest<String> request = HttpRequest.POST("/func",
        objectMapper.writeValueAsString(payload));
    String body = client.toBlocking().retrieve(request);

    assertNotNull(body);
    assertEquals("=", ((Map) objectMapper.readValue(body, HashMap.class)
        .get("payload")).get(Func.RESULT));
  }

  /**
   * Test case function : FLOORMATH(-4.1, -2, -1)
   * request payload json {"payload":{"A1":"-2","A11":"-1","A12":"-4.1","func":"FLOORMATH(A12,A1,A11)"}}
   * response json        {"payload":{"A1":"-2","A11":"-1","A12":"-4.1","func":"FLOORMATH(A12,A1,A11)","result":"-4"}}
   * 结果在 "result" field which is -4
   */
  @Test
  public void testFLOORMATH() throws JsonProcessingException {
    Payload payload = new Payload();
    payload.put("A1", "-2");
    payload.put("A11", "-1");
    payload.put("A12", "-4.1");
    payload.put("func", "FLOORMATH(A12,A1,A11)");
    HttpRequest<String> request = HttpRequest.POST("/func",
        objectMapper.writeValueAsString(payload));
    String body = client.toBlocking().retrieve(request);

    assertNotNull(body);
    assertEquals("-4", ((Map) objectMapper.readValue(body, HashMap.class)
        .get("payload")).get(Func.RESULT));
  }

  /**
   * Test case function : FLOORMATH(-4.1, -2, -1)
   * request payload json {"payload":{"A1":"-2","A11":"-1","A12":"-4.1","func":"FLOORMATH(A12,A1,A11)"}}
   * response json        {"payload":{"A1":"-2","A11":"-1","A12":"-4.1","func":"FLOORMATH(A12,A1,A11)","result":"-4"}}
   * 结果在 "result" field which is -4
   */
  @Test
  public void testSUM() throws JsonProcessingException {
    Payload payload = new Payload();
    payload.put("A1", "-2");
    payload.put("A11", "-1");
    payload.put("A12", "-4.1");
    payload.put("func", "FLOORMATH(A12,A1,A11)");
    HttpRequest<String> request = HttpRequest.POST("/func",
        objectMapper.writeValueAsString(payload));
    String body = client.toBlocking().retrieve(request);

    assertNotNull(body);
    assertEquals("-4", ((Map) objectMapper.readValue(body, HashMap.class)
        .get("payload")).get(Func.RESULT));
  }


}
