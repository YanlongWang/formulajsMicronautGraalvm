globalThis.process = {}
globalThis.Buffer = require('buffer/').Buffer;
globalThis.formulajs = require('@formulajs/formulajs');