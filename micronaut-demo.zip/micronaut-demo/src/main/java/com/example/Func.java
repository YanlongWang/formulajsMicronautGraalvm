package com.example;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.graalvm.polyglot.Context;
import org.graalvm.polyglot.Source;
import org.graalvm.polyglot.Value;

import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Consumes;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.validation.Validated;

/**
 * @author wangya
 * @create 01/04/2022 2:10 PM
 */
@Controller
@Validated
public class Func {

  public static final String FORMULAJS = "formulajs";
  public static final String FUNC = "func";
  public static final String RESULT = "result";
  public static final String BASE_DIR = System.getProperty("user.dir");
  public static final Pattern CAN_CAUCULATE_PATTERN = Pattern.compile("^(\\d+[\\+\\-\\*\\/]\\d+)+$");
  public static final String QUOT_PATTERN_STR = "\".*\"|'.*'";
  public static final Pattern QUOT_PATTERN = Pattern.compile(QUOT_PATTERN_STR);

  @Post(uri = "/func")
  @Consumes(MediaType.APPLICATION_JSON)
  public Payload func(Payload payload) throws IOException {
    String funcStr = replaceParamsInFunction(payload);
    if (canCalculat(funcStr)) {
      try (Context context = Context.create()) {
        Value function = context.eval("js", "()=>" + funcStr + " + \"\"");
        String calculatedResult = function.execute().asString();
        payload.put(RESULT, calculatedResult);
      }
    } else {
      funcStr = parseExcelFunctionString(funcStr);
      Map<String, String> options = new HashMap<>();
      // Enable CommonJS experimental support.
      options.put("js.commonjs-require", "true");
      options.put("js.commonjs-require-cwd", "./");
      options.put("js.commonjs-global-properties", BASE_DIR + "/src/main/resources/globals.js");
      options.put("js.commonjs-core-modules-replacements", "buffer:buffer/");
      try (Context context = Context.newBuilder()
          .allowExperimentalOptions(true)
          .allowAllAccess(true)
          .allowIO(true)
          .options(options)
          .build()) {

        File file = new File(BASE_DIR + "/src/main/resources/formula.min.js");
        String language = Source.findLanguage(file);
        Source source = Source.newBuilder(language, file).build();

        context.eval(source);
        Value result = context.eval("js", funcStr);
        payload.put(RESULT, result.toString());
      }
    }
    return payload;
  }

  /**
   * if the function string can be calculated or not like:
   * 1+2*4-4/2
   */
  private boolean canCalculat(String funcStr) {
    Matcher matcher = CAN_CAUCULATE_PATTERN.matcher(funcStr);
    return matcher.matches();
  }

  /**
   * inputs payload:
   * A1:4
   * A11:5
   * func:A1+A11
   * return:
   * 4+5
   *
   * @param payload payload
   */
  private String replaceParamsInFunction(Payload payload) {
    String funcStr = payload.get(FUNC);
    for (Map.Entry<String, Object> entry : payload.getMap().entrySet()) {
      String k = entry.getKey();
      if (FUNC.equals(k)) {
        continue;
      }
      String v = (String) entry.getValue();
      Pattern p = Pattern.compile(k + "(\\D)+|" + k + "$");
      Matcher m = p.matcher(funcStr);
      while (m.find()) {
        //通过group方法获取前面find查找到的子字符串，start、end方法获取子字符串开始和结束位置
        String head = funcStr.substring(0, m.start());
        String middle = funcStr.substring(m.start(), m.end()).replaceAll(k, v);
        String tail = funcStr.substring(m.end());
        funcStr = head + middle + tail;
      }
    }
    return funcStr;
  }

  /**
   * In excel function,there is one "=". But in formularjs function,there is two "==".
   * Here is to change from "=" to "=="
   *
   * @param funcStr funcStr
   */
  private String parseExcelFunctionString(String funcStr) {
    String originStr = funcStr;
    Matcher matcher = QUOT_PATTERN.matcher(funcStr);
    List<String> oldStrLs = new ArrayList<>();
    while (matcher.find()) {
      String substring = originStr.substring(matcher.start(), matcher.end());
      oldStrLs.add(substring);
      funcStr = StringUtils.replace(funcStr, substring, "\"\"");
    }
    funcStr = StringUtils.replace(funcStr, "=", "==");
    for (String str : oldStrLs) {
      funcStr = funcStr.replaceFirst("\"\"", str);
    }

    return FORMULAJS + "." + funcStr;
  }

}
