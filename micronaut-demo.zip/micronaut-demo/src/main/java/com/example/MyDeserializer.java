package com.example;

import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.KeyDeserializer;

/**
 * @author wangya
 * @create 01/04/2022 6:09 PM
 */
public class MyDeserializer extends KeyDeserializer {

  @Override
  public String deserializeKey(
      String key, DeserializationContext ctxt
  ) {
    return key;
  }

}
