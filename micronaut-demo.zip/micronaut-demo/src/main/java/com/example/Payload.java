package com.example;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * @author wangya
 * @create 01/04/2022 2:36 PM
 */
public class Payload {

  @JsonProperty("payload") @JsonDeserialize(keyUsing = MyDeserializer.class)
  Map<String, Object> map;

  public Payload() {
    this.map = new HashMap<>();
  }

  @JsonCreator
  public Payload(Map<String, Object> map) {
    this.map = map;
  }

  public void put(String key, String value) {
    this.map.put(key, value);
  }

  public String get(String key) {
    return (String) this.map.get(key);
  }

  public void remove(String key) {
    this.map.remove(key);
  }

  public Map<String, Object> getMap() {
    return map;
  }

  public void setMap(Map<String, Object> map) {
    this.map = map;
  }

  @Override
  public String toString() {
    return "Payload{" + "map=" + map + '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Payload)) {
      return false;
    }
    Payload payload = (Payload) o;
    return getMap().equals(payload.getMap());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getMap());
  }

}
